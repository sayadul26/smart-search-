
import React, { useState, useEffect } from 'react';
import { AppView, User, Member, Student, Course, Instructor } from './types';
import Sidebar from './components/Sidebar';
import Navbar from './components/Navbar';
import Dashboard from './components/Dashboard';
import Auth from './components/Auth';
import MemberList from './components/MemberList';
import StudentList from './components/StudentList';
import CourseList from './components/CourseList';
import CertificateGen from './components/CertificateGen';
import AdBanner from './components/AdBanner';
import ChatBox from './components/ChatBox';
import InstructorList from './components/InstructorList';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<AppView>(AppView.DASHBOARD);
  
  // App State
  const [members, setMembers] = useState<Member[]>([
    { id: '1', name: 'Dr. Sarah Connor', email: 'sarah@edu.com', role: 'Admin', joinedDate: '2023-01-15' },
    { id: '2', name: 'John Smith', email: 'john@edu.com', role: 'Instructor', joinedDate: '2023-03-22' },
  ]);
  
  const [students, setStudents] = useState<Student[]>([
    { id: '101', name: 'Alice Wong', email: 'alice@student.com', enrolledCourse: 'React Mastery', progress: 85 },
    { id: '102', name: 'Bob Jenkins', email: 'bob@student.com', enrolledCourse: 'Python Data Science', progress: 42 },
  ]);

  const [courses, setCourses] = useState<Course[]>([
    { id: 'c1', title: 'React Mastery', instructor: 'John Smith', studentsCount: 156, category: 'Web Dev', image: 'https://picsum.photos/seed/react/400/250' },
    { id: 'c2', title: 'Python Data Science', instructor: 'Dr. Sarah Connor', studentsCount: 230, category: 'Data Science', image: 'https://picsum.photos/seed/python/400/250' },
    { id: 'c3', title: 'UI/UX Principles', instructor: 'Alex Rivera', studentsCount: 89, category: 'Design', image: 'https://picsum.photos/seed/design/400/250' },
  ]);

  const [instructors, setInstructors] = useState<Instructor[]>([
    {
      id: 'inst1',
      name: 'Dr. Sarah Connor',
      email: 'sarah.connor@pesda.edu',
      bio: 'Ph.D. in Structural Engineering with a focus on seismic resilience and automated construction technologies. Leading the department of Civil Systems for over a decade.',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=400',
      specialties: ['Structural Engineering', 'Seismic Design', 'Automation'],
      phone: '+1 (555) 012-3456'
    },
    {
      id: 'inst2',
      name: 'Eng. John Smith',
      email: 'j.smith@pesda.edu',
      bio: 'Senior Software Architect specializing in embedded systems and real-time data processing. Passionate about bridging the gap between hardware and high-level software.',
      avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=400',
      specialties: ['Embedded Systems', 'Real-time OS', 'C++'],
      phone: '+1 (555) 987-6543'
    },
    {
      id: 'inst3',
      name: 'Prof. Elena Rodriguez',
      email: 'e.rodriguez@pesda.edu',
      bio: 'Researcher in Renewable Energy Systems. Focused on optimizing solar grid efficiency and next-generation battery storage technologies for smart cities.',
      avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=400',
      specialties: ['Renewable Energy', 'Smart Grids', 'Power Electronics'],
      phone: '+1 (555) 246-8135'
    }
  ]);

  const handleLogin = (userData: User) => {
    setUser(userData);
  };

  const handleLogout = () => {
    setUser(null);
  };

  const handleUpdateCourse = (updatedCourse: Course) => {
    setCourses(courses.map(c => c.id === updatedCourse.id ? updatedCourse : c));
  };

  if (!user) {
    return <Auth onLogin={handleLogin} />;
  }

  const renderView = () => {
    switch (currentView) {
      case AppView.DASHBOARD:
        return <Dashboard 
          memberCount={members.length} 
          studentCount={students.length} 
          courseCount={courses.length}
          recentStudents={students.slice(0, 5)}
        />;
      case AppView.MEMBERS:
        return <MemberList members={members} onAdd={(m) => setMembers([...members, m])} onDelete={(id) => setMembers(members.filter(m => m.id !== id))} />;
      case AppView.STUDENTS:
        return <StudentList students={students} onAdd={(s) => setStudents([...students, s])} onDelete={(id) => setStudents(students.filter(s => s.id !== id))} />;
      case AppView.COURSES:
        return <CourseList courses={courses} onAdd={(c) => setCourses([...courses, c])} onUpdate={handleUpdateCourse} />;
      case AppView.INSTRUCTORS:
        return <InstructorList instructors={instructors} />;
      case AppView.CERTIFICATES:
        return <CertificateGen students={students} />;
      case AppView.ADS:
        return <AdBanner />;
      default:
        return <Dashboard memberCount={members.length} studentCount={students.length} courseCount={courses.length} recentStudents={students.slice(0, 5)} />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar currentView={currentView} setView={setCurrentView} />
      <div className="flex-1 flex flex-col min-w-0 bg-slate-50 overflow-hidden">
        <Navbar user={user} onLogout={handleLogout} />
        <main className="flex-1 overflow-y-auto p-4 md:p-8">
          <div className="max-w-7xl mx-auto animate-fadeIn">
            {renderView()}
          </div>
        </main>
      </div>
      <ChatBox />
    </div>
  );
};

export default App;
