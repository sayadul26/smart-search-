
export interface Member {
  id: string;
  name: string;
  email: string;
  role: 'Admin' | 'Instructor' | 'Moderator';
  joinedDate: string;
}

export interface Student {
  id: string;
  name: string;
  email: string;
  enrolledCourse: string;
  progress: number;
}

export interface Course {
  id: string;
  title: string;
  instructor: string;
  studentsCount: number;
  image: string;
  category: string;
}

export interface Instructor {
  id: string;
  name: string;
  email: string;
  bio: string;
  avatar: string;
  specialties: string[];
  phone: string;
}

export interface User {
  name: string;
  email: string;
  isLoggedIn: boolean;
}

export enum AppView {
  DASHBOARD = 'DASHBOARD',
  MEMBERS = 'MEMBERS',
  STUDENTS = 'STUDENTS',
  COURSES = 'COURSES',
  INSTRUCTORS = 'INSTRUCTORS',
  CERTIFICATES = 'CERTIFICATES',
  ADS = 'ADS'
}
