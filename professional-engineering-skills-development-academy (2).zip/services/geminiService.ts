
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateCertificateText = async (studentName: string, courseName: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate a formal, inspiring one-sentence congratulatory message for a certificate awarded to ${studentName} for completing the course "${courseName}".`,
      config: {
        temperature: 0.7,
      },
    });
    return response.text?.trim() || "For outstanding performance and dedication to excellence.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "This certificate is awarded in recognition of the successful completion of the course requirements.";
  }
};

export const suggestNewCourse = async (category: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Suggest a trending course title and a 1-sentence description in the field of ${category}. Return as JSON.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING }
          },
          required: ["title", "description"]
        }
      }
    });
    return JSON.parse(response.text || '{}');
  } catch (error) {
    return { title: "Modern Web Development", description: "Mastering the stack from end to end." };
  }
};

export const createEduChat = () => {
  return ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: 'You are the EduStream Platform Tutor. You help administrators manage their school. You are friendly, concise, and professional. You can answer questions about students, courses, and educational management.',
    },
  });
};
