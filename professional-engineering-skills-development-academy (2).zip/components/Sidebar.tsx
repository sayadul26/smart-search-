
import React from 'react';
import { AppView } from '../types';
import Logo from './Logo';

interface SidebarProps {
  currentView: AppView;
  setView: (view: AppView) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView }) => {
  const menuItems = [
    { view: AppView.DASHBOARD, icon: 'fa-gauge-high', label: 'Dashboard' },
    { view: AppView.MEMBERS, icon: 'fa-users-gear', label: 'Team Members' },
    { view: AppView.INSTRUCTORS, icon: 'fa-chalkboard-user', label: 'Instructors' },
    { view: AppView.STUDENTS, icon: 'fa-user-graduate', label: 'Students' },
    { view: AppView.COURSES, icon: 'fa-book-open', label: 'Courses' },
    { view: AppView.CERTIFICATES, icon: 'fa-certificate', label: 'Certificates' },
    { view: AppView.ADS, icon: 'fa-rectangle-ad', label: 'Campaigns' },
  ];

  return (
    <div className="w-20 md:w-64 bg-slate-900 text-white flex flex-col transition-all duration-300">
      <div className="p-6">
        <div className="hidden md:block">
          <Logo variant="white" />
        </div>
        <div className="md:hidden flex justify-center">
          <Logo variant="icon" />
        </div>
      </div>
      
      <nav className="flex-1 px-4 py-4 space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.view}
            onClick={() => setView(item.view)}
            className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all ${
              currentView === item.view 
                ? 'bg-indigo-600 shadow-lg text-white' 
                : 'hover:bg-slate-800 text-slate-400'
            }`}
          >
            <i className={`fa-solid ${item.icon} text-lg`}></i>
            <span className="hidden md:block font-medium">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-4 mt-auto border-t border-slate-800">
        <div className="hidden md:block p-4 bg-slate-800/40 rounded-2xl">
          <p className="text-xs text-slate-500 uppercase font-bold tracking-widest mb-1">Academy Status</p>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></span>
            <span className="text-sm font-medium">Core Systems Active</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
