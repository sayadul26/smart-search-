
import React, { useState } from 'react';
import { User } from '../types';
import Logo from './Logo';

interface AuthProps {
  onLogin: (user: User) => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin({
      name: name || (email.split('@')[0].charAt(0).toUpperCase() + email.split('@')[0].slice(1)),
      email: email,
      isLoggedIn: true
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-900 px-4 py-12 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-indigo-600/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-violet-600/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>

      <div className="max-w-md w-full bg-white rounded-[2.5rem] shadow-2xl overflow-hidden transform transition-all relative z-10 border border-slate-100">
        <div className="bg-slate-50 p-10 flex flex-col items-center text-center border-b border-slate-100">
          <Logo variant="full" className="scale-125 mb-8" />
          <p className="text-slate-500 font-medium max-w-[240px]">
            Log in to the Professional Engineering Skills Development Portal
          </p>
        </div>

        <form className="p-8 space-y-6" onSubmit={handleSubmit}>
          <div className="flex bg-slate-100 p-1 rounded-2xl mb-6">
            <button 
              type="button" 
              onClick={() => setIsLogin(true)}
              className={`flex-1 py-2.5 text-sm font-bold rounded-xl transition-all ${isLogin ? 'bg-white shadow-md text-indigo-600' : 'text-slate-500'}`}
            >
              Portal Login
            </button>
            <button 
              type="button" 
              onClick={() => setIsLogin(false)}
              className={`flex-1 py-2.5 text-sm font-bold rounded-xl transition-all ${!isLogin ? 'bg-white shadow-md text-indigo-600' : 'text-slate-500'}`}
            >
              Registration
            </button>
          </div>

          {!isLogin && (
            <div className="animate-fadeIn">
              <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2 px-1">Full Academic Name</label>
              <div className="relative">
                <i className="fa-solid fa-user absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                <input 
                  type="text" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-indigo-500 transition-all" 
                  placeholder="John Doe"
                  required
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2 px-1">Institutional Email</label>
            <div className="relative">
              <i className="fa-solid fa-envelope absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-indigo-500 transition-all" 
                placeholder="you@pesda.edu"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2 px-1">Security Password</label>
            <div className="relative">
              <i className="fa-solid fa-shield-halved absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:border-indigo-500 transition-all" 
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          <button 
            type="submit"
            className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-2xl shadow-xl shadow-indigo-200 transition-all transform active:scale-[0.98]"
          >
            {isLogin ? 'Enter Portal' : 'Create Account'}
          </button>
          
          <div className="flex items-center justify-between px-2">
            <a href="#" className="text-xs text-slate-400 hover:text-indigo-600 transition-colors font-medium">Forgot Access?</a>
            <p className="text-[10px] text-slate-300 font-bold uppercase tracking-tighter">Secure Terminal 01</p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Auth;
