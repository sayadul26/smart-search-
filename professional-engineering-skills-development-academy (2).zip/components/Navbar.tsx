
import React from 'react';
import { User } from '../types';
import Logo from './Logo';

interface NavbarProps {
  user: User;
  onLogout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, onLogout }) => {
  return (
    <header className="h-20 bg-white border-b border-slate-200 flex items-center justify-between px-6 md:px-8 z-10 shadow-sm">
      <div className="flex items-center gap-4">
        <div className="md:hidden">
           <Logo variant="icon" />
        </div>
        <div className="hidden md:flex flex-col">
          <h2 className="text-lg font-bold text-slate-800 leading-none">Welcome, {user.name}</h2>
          <span className="text-[10px] text-indigo-600 font-bold uppercase tracking-widest mt-1">Authorized Session</span>
        </div>
      </div>

      <div className="flex items-center gap-6">
        <button className="relative p-2 text-slate-400 hover:text-indigo-600 transition-colors">
          <i className="fa-solid fa-bell text-xl"></i>
          <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-rose-500 rounded-full border-2 border-white"></span>
        </button>
        
        <div className="h-10 w-[1px] bg-slate-200"></div>

        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-bold text-slate-800 leading-none">{user.name}</p>
            <p className="text-[10px] text-slate-400 mt-1">{user.email}</p>
          </div>
          <button 
            onClick={onLogout}
            className="w-10 h-10 rounded-xl bg-slate-50 hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition-all flex items-center justify-center border border-slate-100"
            title="Secure Logout"
          >
            <i className="fa-solid fa-power-off"></i>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
