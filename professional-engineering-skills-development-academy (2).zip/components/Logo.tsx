
import React from 'react';

interface LogoProps {
  variant?: 'full' | 'icon' | 'white';
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ variant = 'full', className = '' }) => {
  const isWhite = variant === 'white';
  const primaryColor = isWhite ? "white" : "#4f46e5"; // indigo-600
  const secondaryColor = isWhite ? "#a5b4fc" : "#6366f1"; // indigo-500
  const accentColor = isWhite ? "rgba(255,255,255,0.3)" : "rgba(79,70,229,0.1)";
  
  const Icon = () => (
    <svg viewBox="0 0 100 100" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Outer Rotating Gear Shape */}
      <path d="M50 10 L58 10 L60 18 A32 32 0 0 1 72 23 L80 17 L86 23 L80 31 A32 32 0 0 1 85 43 L93 45 L93 53 L85 55 A32 32 0 0 1 80 67 L86 75 L80 81 L72 75 A32 32 0 0 1 60 80 L58 88 L50 88 L48 80 A32 32 0 0 1 36 75 L28 81 L22 75 L28 67 A32 32 0 0 1 23 55 L15 53 L15 45 L23 43 A32 32 0 0 1 28 31 L22 23 L28 17 L36 23 A32 32 0 0 1 48 18 L50 10 Z" 
            stroke={primaryColor} strokeWidth="4" strokeLinejoin="round" />
      
      {/* Internal Digital Circuitry Pattern */}
      <circle cx="50" cy="50" r="18" stroke={secondaryColor} strokeWidth="3" />
      <path d="M50 32 V40 M50 60 V68 M32 50 H40 M60 50 H68" stroke={secondaryColor} strokeWidth="3" strokeLinecap="round" />
      <path d="M38 38 L44 44 M56 56 L62 62 M38 62 L44 56 M56 44 L62 38" stroke={secondaryColor} strokeWidth="2" strokeLinecap="round" />
      
      {/* Center Core Node */}
      <circle cx="50" cy="50" r="6" fill={primaryColor} />
      
      {/* Tech Pulses */}
      <circle cx="50" cy="50" r="38" stroke={accentColor} strokeWidth="1" strokeDasharray="4 8" />
    </svg>
  );

  if (variant === 'icon') {
    return (
      <div className={`w-10 h-10 ${className}`}>
        <Icon />
      </div>
    );
  }

  return (
    <div className={`flex items-center gap-4 ${className}`}>
      <div className="w-12 h-12 flex-shrink-0 drop-shadow-sm">
        <Icon />
      </div>
      <div className="flex flex-col leading-none">
        <div className="flex items-baseline gap-1">
          <span className={`text-2xl font-black tracking-tighter ${isWhite ? 'text-white' : 'text-slate-900'}`}>
            PESDA
          </span>
          <div className={`w-1.5 h-1.5 rounded-full ${isWhite ? 'bg-indigo-400' : 'bg-indigo-600'} animate-pulse`}></div>
        </div>
        <span className={`text-[8px] font-bold uppercase tracking-[0.3em] ${isWhite ? 'text-indigo-200' : 'text-indigo-600'}`}>
          Smart Engineering
        </span>
      </div>
    </div>
  );
};

export default Logo;
