
import React, { useState } from 'react';
import { Student } from '../types';
import { generateCertificateText } from '../services/geminiService';

interface CertificateGenProps {
  students: Student[];
}

const CertificateGen: React.FC<CertificateGenProps> = ({ students }) => {
  const [selectedStudent, setSelectedStudent] = useState<string>('');
  const [courseName, setCourseName] = useState<string>('');
  const [message, setMessage] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [showCertificate, setShowCertificate] = useState(false);

  const handleGenerate = async () => {
    if (!selectedStudent || !courseName) return;
    setIsGenerating(true);
    const student = students.find(s => s.id === selectedStudent);
    const text = await generateCertificateText(student?.name || 'Student', courseName);
    setMessage(text);
    setIsGenerating(false);
    setShowCertificate(true);
  };

  const studentObj = students.find(s => s.id === selectedStudent);

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div className="text-center">
        <h1 className="text-4xl font-extrabold text-slate-900 mb-2">Academic Awards</h1>
        <p className="text-slate-500">Celebrate excellence with professional, AI-powered certificates.</p>
      </div>

      <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">Select Student</label>
            <select 
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500"
              value={selectedStudent}
              onChange={(e) => setSelectedStudent(e.target.value)}
            >
              <option value="">Choose a student...</option>
              {students.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">Course Completion</label>
            <input 
              type="text" 
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500"
              placeholder="e.g. Advanced JavaScript"
              value={courseName}
              onChange={(e) => setCourseName(e.target.value)}
            />
          </div>
        </div>

        <button 
          onClick={handleGenerate}
          disabled={isGenerating || !selectedStudent || !courseName}
          className="w-full py-4 bg-indigo-600 text-white font-bold rounded-xl shadow-lg hover:bg-indigo-700 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {isGenerating ? <i className="fa-solid fa-spinner animate-spin"></i> : <i className="fa-solid fa-award"></i>}
          Generate Award Document
        </button>
      </div>

      {showCertificate && studentObj && (
        <div className="relative animate-fadeIn">
          <div className="bg-[#fffcf0] border-[16px] border-[#c5a059] p-12 md:p-20 shadow-2xl rounded-sm text-center relative overflow-hidden">
            {/* Background Decorative elements */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-[#c5a059]/10 rounded-full -translate-y-1/2 translate-x-1/2"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-[#c5a059]/10 rounded-full translate-y-1/2 -translate-x-1/2"></div>
            
            <div className="relative z-10 border-2 border-[#c5a059]/30 p-8">
              <div className="mb-12">
                <i className="fa-solid fa-ribbon text-6xl text-[#c5a059] mb-6"></i>
                <h2 className="text-4xl md:text-5xl font-serif text-[#8b6d31] uppercase tracking-[0.2em] font-light">Certificate of Completion</h2>
              </div>
              
              <p className="text-xl italic text-slate-600 mb-4 font-serif">This is to certify that</p>
              <h3 className="text-4xl md:text-6xl font-bold text-slate-900 mb-8 font-serif border-b-2 border-slate-200 inline-block px-12 pb-2">{studentObj.name}</h3>
              
              <p className="text-xl text-slate-600 mb-8 max-w-2xl mx-auto font-serif leading-relaxed">
                has successfully completed all the requirements for the professional curriculum in
              </p>
              
              <h4 className="text-3xl font-bold text-[#8b6d31] mb-12 uppercase tracking-widest">{courseName}</h4>
              
              <div className="bg-slate-50/50 p-6 rounded-xl mb-12 italic text-slate-500 text-lg border border-slate-100">
                "{message}"
              </div>

              <div className="flex flex-col md:flex-row justify-between items-end gap-12 mt-16 px-12">
                <div className="text-center">
                  <div className="w-48 border-b-2 border-slate-300 font-serif italic text-slate-400 pb-1">Sarah Connor</div>
                  <p className="text-xs font-bold uppercase tracking-widest text-slate-500 mt-2">Program Director</p>
                </div>
                
                <div className="w-24 h-24 rounded-full border-4 border-[#c5a059] flex items-center justify-center rotate-12 bg-white shadow-inner">
                   <i className="fa-solid fa-certificate text-4xl text-[#c5a059]"></i>
                </div>

                <div className="text-center">
                   <div className="w-48 border-b-2 border-slate-300 font-serif italic text-slate-400 pb-1">{new Date().toLocaleDateString()}</div>
                   <p className="text-xs font-bold uppercase tracking-widest text-slate-500 mt-2">Date of Issue</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-8 flex justify-center gap-4">
             <button className="px-6 py-3 bg-white border border-slate-200 rounded-xl font-bold text-slate-700 hover:bg-slate-50 transition-colors shadow-sm">
                <i className="fa-solid fa-print mr-2"></i> Print Certificate
             </button>
             <button className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-md">
                <i className="fa-solid fa-share-nodes mr-2"></i> Share Recognition
             </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default CertificateGen;
