
import React from 'react';
import { Instructor } from '../types';

interface InstructorListProps {
  instructors: Instructor[];
}

const InstructorList: React.FC<InstructorListProps> = ({ instructors }) => {
  return (
    <div className="space-y-8 animate-fadeIn">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Instructor Directory</h1>
          <p className="text-slate-500">Meet our team of world-class engineering experts.</p>
        </div>
        <button className="px-5 py-2.5 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-all shadow-md">
          <i className="fa-solid fa-user-plus mr-2"></i> Register Instructor
        </button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        {instructors.map((inst) => (
          <div key={inst.id} className="bg-white rounded-[2.5rem] shadow-sm border border-slate-100 overflow-hidden flex flex-col md:flex-row p-6 gap-8 hover:shadow-xl transition-all">
            <div className="w-full md:w-48 h-48 flex-shrink-0">
              <img 
                src={inst.avatar} 
                alt={inst.name} 
                className="w-full h-full object-cover rounded-3xl shadow-lg border-4 border-slate-50"
              />
            </div>
            
            <div className="flex-1 flex flex-col">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="text-2xl font-bold text-slate-900">{inst.name}</h3>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {inst.specialties.map((spec, i) => (
                      <span key={i} className="px-2 py-0.5 bg-blue-50 text-blue-600 rounded-lg text-[10px] font-bold uppercase tracking-wider border border-blue-100">
                        {spec}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="flex gap-2">
                  <a href={`mailto:${inst.email}`} className="w-10 h-10 bg-slate-50 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl flex items-center justify-center transition-all border border-slate-100">
                    <i className="fa-solid fa-envelope"></i>
                  </a>
                  <a href={`tel:${inst.phone}`} className="w-10 h-10 bg-slate-50 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl flex items-center justify-center transition-all border border-slate-100">
                    <i className="fa-solid fa-phone"></i>
                  </a>
                </div>
              </div>
              
              <p className="text-slate-500 text-sm leading-relaxed mb-6 flex-1">
                {inst.bio}
              </p>
              
              <div className="flex items-center justify-between pt-4 border-t border-slate-50 mt-auto">
                <div className="flex items-center gap-4">
                  <div>
                    <p className="text-[10px] uppercase font-bold text-slate-400 tracking-widest">Office Hours</p>
                    <p className="text-xs font-bold text-slate-700">Mon-Fri: 9AM - 11AM</p>
                  </div>
                </div>
                <button className="px-4 py-2 bg-slate-50 text-slate-600 text-xs font-bold rounded-lg hover:bg-blue-50 hover:text-blue-600 transition-all border border-slate-100">
                  View Published Courses
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default InstructorList;
