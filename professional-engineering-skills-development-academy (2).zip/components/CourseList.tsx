
import React, { useState, useMemo, useRef } from 'react';
import { Course } from '../types';
import { suggestNewCourse } from '../services/geminiService';

interface CourseListProps {
  courses: Course[];
  onAdd: (course: Course) => void;
  onUpdate: (course: Course) => void;
}

const CourseList: React.FC<CourseListProps> = ({ courses, onAdd, onUpdate }) => {
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Modals visibility
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Form States
  const [formTitle, setFormTitle] = useState('');
  const [formCategory, setFormCategory] = useState('');
  const [formInstructor, setFormInstructor] = useState('');
  const [formImage, setFormImage] = useState('');

  const resetForm = () => {
    setFormTitle('');
    setFormCategory('');
    setFormInstructor('');
    setFormImage('');
  };

  const handleAISuggestion = async () => {
    setLoading(true);
    const suggestion = await suggestNewCourse('Artificial Intelligence');
    setLoading(false);
    
    if (suggestion.title) {
      onAdd({
        id: Math.random().toString(36).substr(2, 9),
        title: suggestion.title,
        instructor: 'Gemini AI',
        studentsCount: 0,
        category: 'Future Tech',
        image: `https://picsum.photos/seed/${suggestion.title}/400/250`
      });
    }
  };

  const startEditing = (course: Course) => {
    setEditingCourse(course);
    setFormTitle(course.title);
    setFormCategory(course.category);
    setFormInstructor(course.instructor);
    setFormImage(course.image);
  };

  const handleUpdate = () => {
    if (editingCourse && formTitle && formCategory && formInstructor) {
      onUpdate({
        ...editingCourse,
        title: formTitle,
        category: formCategory,
        instructor: formInstructor,
        image: formImage || editingCourse.image
      });
      setEditingCourse(null);
      resetForm();
    }
  };

  const handleManualAdd = () => {
    if (formTitle && formCategory && formInstructor) {
      onAdd({
        id: Math.random().toString(36).substr(2, 9),
        title: formTitle,
        instructor: formInstructor,
        studentsCount: 0,
        category: formCategory,
        image: formImage || `https://picsum.photos/seed/${formTitle.replace(/\s+/g, '')}/400/250`
      });
      setIsAddModalOpen(false);
      resetForm();
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const filteredCourses = useMemo(() => {
    const query = searchQuery.toLowerCase();
    return courses.filter(course => 
      course.title.toLowerCase().includes(query) || 
      course.category.toLowerCase().includes(query)
    );
  }, [courses, searchQuery]);

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Course Catalog</h1>
          <p className="text-slate-500 text-sm mt-1">Curate and manage your engineering educational content.</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <button 
            disabled={loading}
            onClick={handleAISuggestion}
            className="px-5 py-2.5 bg-indigo-50 text-indigo-700 rounded-xl font-bold hover:bg-indigo-100 transition-all border border-indigo-200 flex items-center gap-2 disabled:opacity-50 shadow-sm"
          >
            {loading ? <i className="fa-solid fa-spinner animate-spin"></i> : <i className="fa-solid fa-wand-magic-sparkles"></i>}
            AI Course Idea
          </button>
          <button 
            onClick={() => { resetForm(); setIsAddModalOpen(true); }}
            className="px-5 py-2.5 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-all shadow-md"
          >
            <i className="fa-solid fa-plus mr-2"></i> Create Course
          </button>
        </div>
      </div>

      {/* Search Bar Section */}
      <div className="relative max-w-xl">
        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
          <i className="fa-solid fa-magnifying-glass text-slate-400"></i>
        </div>
        <input 
          type="text"
          placeholder="Search by course title or category..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-11 pr-4 py-3.5 bg-white border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all shadow-sm text-slate-700"
        />
        {searchQuery && (
          <button 
            onClick={() => setSearchQuery('')}
            className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-400 hover:text-slate-600"
          >
            <i className="fa-solid fa-circle-xmark"></i>
          </button>
        )}
      </div>

      {filteredCourses.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredCourses.map((course) => (
            <div key={course.id} className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden hover:shadow-xl transition-all group animate-fadeIn">
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={course.image} 
                  alt={course.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-white/90 backdrop-blur-md rounded-lg text-[10px] font-bold text-slate-800 uppercase tracking-widest shadow-sm">
                    {course.category}
                  </span>
                </div>
                <button 
                  onClick={() => startEditing(course)}
                  className="absolute top-4 right-4 w-10 h-10 bg-white/90 backdrop-blur-md rounded-xl flex items-center justify-center text-slate-600 hover:text-indigo-600 shadow-sm transition-all opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0"
                >
                  <i className="fa-solid fa-pen-to-square"></i>
                </button>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-slate-900 mb-1 group-hover:text-indigo-600 transition-colors">
                  {course.title}
                </h3>
                <p className="text-sm text-slate-400 mb-6 flex items-center gap-2">
                  <i className="fa-solid fa-chalkboard-user"></i> {course.instructor}
                </p>
                
                <div className="flex items-center justify-between py-4 border-t border-slate-50">
                  <div className="flex items-center gap-2">
                    <div className="flex -space-x-2">
                      {[1,2,3].map(i => (
                        <img key={i} src={`https://i.pravatar.cc/50?u=${course.id + i}`} className="w-8 h-8 rounded-full border-2 border-white" alt="avatar" />
                      ))}
                    </div>
                    <span className="text-xs font-bold text-slate-400">+{course.studentsCount}</span>
                  </div>
                  <button 
                    onClick={() => startEditing(course)}
                    className="text-indigo-600 font-bold text-sm flex items-center gap-1 hover:gap-2 transition-all"
                  >
                    Edit Details <i className="fa-solid fa-arrow-right-long"></i>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-20 bg-white rounded-[2rem] border-2 border-dashed border-slate-100">
          <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-300 text-3xl mb-4">
            <i className="fa-solid fa-book-open"></i>
          </div>
          <h3 className="text-xl font-bold text-slate-800">No courses found</h3>
          <p className="text-slate-400 max-w-xs text-center mt-2">We couldn't find any courses matching your search.</p>
          <button 
            onClick={() => setSearchQuery('')}
            className="mt-6 text-indigo-600 font-bold hover:underline"
          >
            Clear Search
          </button>
        </div>
      )}

      {/* Modals Container */}
      {(editingCourse || isAddModalOpen) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl p-8 animate-popIn max-h-[90vh] overflow-y-auto custom-scrollbar">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center">
                <i className={`fa-solid ${editingCourse ? 'fa-pen-nib' : 'fa-plus'}`}></i>
              </div>
              <h3 className="text-2xl font-bold text-slate-900">{editingCourse ? 'Edit Course' : 'Create New Course'}</h3>
            </div>
            
            <div className="space-y-5">
              {/* Image Upload Area */}
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 px-1">Course Banner (Upload Pic)</label>
                <input 
                  type="file" 
                  ref={fileInputRef}
                  onChange={handleImageChange}
                  accept="image/*"
                  className="hidden"
                />
                
                {formImage ? (
                  <div className="relative group rounded-2xl overflow-hidden border-2 border-indigo-100 shadow-inner h-40">
                    <img src={formImage} alt="Selected Banner" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                      <button 
                        onClick={triggerFileInput}
                        className="w-10 h-10 bg-white rounded-full text-indigo-600 flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
                        title="Change Image"
                      >
                        <i className="fa-solid fa-camera"></i>
                      </button>
                      <button 
                        onClick={() => setFormImage('')}
                        className="w-10 h-10 bg-white rounded-full text-rose-500 flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
                        title="Remove Image"
                      >
                        <i className="fa-solid fa-trash-can"></i>
                      </button>
                    </div>
                  </div>
                ) : (
                  <button 
                    onClick={triggerFileInput}
                    className="w-full h-40 bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl flex flex-col items-center justify-center gap-2 text-slate-400 hover:border-indigo-400 hover:bg-indigo-50 hover:text-indigo-500 transition-all group"
                  >
                    <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                       <i className="fa-solid fa-image text-xl"></i>
                    </div>
                    <span className="text-xs font-bold uppercase tracking-widest">Click to Upload Pic</span>
                  </button>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 px-1">Course Title</label>
                <input 
                  type="text" 
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" 
                  placeholder="e.g. Advanced Structural Mechanics"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 px-1">Category</label>
                  <input 
                    type="text" 
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" 
                    placeholder="Engineering"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 px-1">Instructor</label>
                  <input 
                    type="text" 
                    value={formInstructor}
                    onChange={(e) => setFormInstructor(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-indigo-500 transition-all" 
                    placeholder="Name"
                  />
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <button 
                  onClick={() => { setEditingCourse(null); setIsAddModalOpen(false); resetForm(); }}
                  className="flex-1 py-3 bg-slate-100 text-slate-500 font-bold rounded-xl hover:bg-slate-200 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={editingCourse ? handleUpdate : handleManualAdd}
                  className="flex-1 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 shadow-lg shadow-indigo-100 transition-all disabled:opacity-50"
                  disabled={!formTitle || !formCategory || !formInstructor}
                >
                  {editingCourse ? 'Save Changes' : 'Add Course'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CourseList;
