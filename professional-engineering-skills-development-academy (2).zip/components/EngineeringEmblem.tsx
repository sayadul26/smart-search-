
import React from 'react';

interface EngineeringEmblemProps {
  className?: string;
}

const EngineeringEmblem: React.FC<EngineeringEmblemProps> = ({ className = '' }) => {
  return (
    <div className={`relative group ${className}`}>
      {/* Decorative Rotating Border */}
      <div className="absolute inset-0 rounded-full border-2 border-dashed border-indigo-500/30 animate-[spin_20s_linear_infinite] group-hover:border-indigo-500/60 transition-colors"></div>
      
      {/* Outer Glow */}
      <div className="absolute -inset-1 bg-indigo-500/10 rounded-full blur-md opacity-0 group-hover:opacity-100 transition-opacity"></div>
      
      {/* The "Pic Logo" Container */}
      <div className="relative w-full h-full p-2">
        <div className="w-full h-full rounded-full overflow-hidden border-4 border-white shadow-xl bg-slate-100">
          <img 
            src="https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&q=80&w=400" 
            alt="Advanced Robotics Engineering"
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
          />
          {/* Overlay for branding feel */}
          <div className="absolute inset-0 bg-indigo-900/10 group-hover:bg-transparent transition-colors"></div>
        </div>
      </div>
      
      {/* Identification Badge */}
      <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-3 py-1 bg-slate-900 text-[8px] font-black text-white rounded-full uppercase tracking-widest shadow-lg whitespace-nowrap border border-white/20">
        Industry 4.0 Verified
      </div>
    </div>
  );
};

export default EngineeringEmblem;
