
import React, { useState } from 'react';
import { Student } from '../types';

interface StudentListProps {
  students: Student[];
  onAdd: (student: Student) => void;
  onDelete: (id: string) => void;
}

const StudentList: React.FC<StudentListProps> = ({ students, onAdd, onDelete }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [course, setCourse] = useState('');

  const handleAdd = () => {
    if (!name || !email) return;
    onAdd({
      id: Date.now().toString(),
      name,
      email,
      enrolledCourse: course || 'Not Assigned',
      progress: 0
    });
    setName('');
    setEmail('');
    setCourse('');
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
       <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Student Directory</h1>
          <p className="text-slate-500">Overview of all active learners in the system.</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="px-6 py-3 bg-rose-500 text-white rounded-xl font-bold hover:bg-rose-600 transition-all shadow-md flex items-center gap-2"
        >
          <i className="fa-solid fa-user-plus"></i> Enroll Student
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {students.map((student) => (
          <div key={student.id} className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow relative group">
            <button 
              onClick={() => onDelete(student.id)}
              className="absolute top-4 right-4 text-slate-200 hover:text-rose-500 transition-colors"
            >
              <i className="fa-solid fa-xmark"></i>
            </button>
            <div className="flex items-center gap-4 mb-6">
              <div className="w-14 h-14 rounded-full bg-slate-100 overflow-hidden border-2 border-indigo-50">
                <img src={`https://i.pravatar.cc/150?u=${student.id}`} alt={student.name} />
              </div>
              <div>
                <h4 className="font-bold text-slate-800 text-lg">{student.name}</h4>
                <p className="text-xs text-slate-400 font-medium">{student.email}</p>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <p className="text-[10px] uppercase tracking-widest font-bold text-slate-400 mb-1">Enrolled In</p>
                <div className="flex items-center gap-2 text-sm font-bold text-indigo-600">
                  <i className="fa-solid fa-book-bookmark"></i>
                  {student.enrolledCourse}
                </div>
              </div>
              <div>
                <div className="flex justify-between items-center mb-1">
                  <p className="text-[10px] uppercase tracking-widest font-bold text-slate-400">Completion Progress</p>
                  <span className="text-xs font-bold text-slate-800">{student.progress}%</span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-rose-500 transition-all duration-1000" 
                    style={{ width: `${student.progress}%` }}
                  ></div>
                </div>
              </div>
            </div>
            
            <button className="w-full mt-6 py-2 bg-slate-50 hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 text-sm font-bold rounded-xl transition-all border border-slate-100 hover:border-indigo-100">
              View Gradebook
            </button>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl p-8 transform animate-popIn">
            <h3 className="text-2xl font-bold text-slate-900 mb-6 text-center">Enroll New Student</h3>
            <div className="space-y-4">
              <input 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-rose-500" 
                placeholder="Full Name"
              />
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-rose-500" 
                placeholder="Email Address"
              />
              <input 
                type="text" 
                value={course}
                onChange={(e) => setCourse(e.target.value)}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-rose-500" 
                placeholder="Course Title"
              />
              <div className="flex gap-4 pt-4">
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-3 font-bold text-slate-400 hover:text-slate-600"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleAdd}
                  className="flex-1 py-3 bg-rose-500 text-white font-bold rounded-xl hover:bg-rose-600 shadow-lg shadow-rose-200 transition-all"
                >
                  Enroll Now
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentList;
