
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Student } from '../types';
import EngineeringEmblem from './EngineeringEmblem';

interface DashboardProps {
  memberCount: number;
  studentCount: number;
  courseCount: number;
  recentStudents: Student[];
}

const Dashboard: React.FC<DashboardProps> = ({ memberCount, studentCount, courseCount, recentStudents }) => {
  const data = [
    { name: 'Jan', enrollment: 400 },
    { name: 'Feb', enrollment: 300 },
    { name: 'Mar', enrollment: 600 },
    { name: 'Apr', enrollment: 800 },
    { name: 'May', enrollment: 500 },
    { name: 'Jun', enrollment: 900 },
  ];

  const StatCard = ({ icon, label, val, color }: { icon: string, label: string, val: number, color: string }) => (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-6">
      <div className={`${color} w-14 h-14 rounded-2xl flex items-center justify-center text-white text-2xl shadow-inner`}>
        <i className={`fa-solid ${icon}`}></i>
      </div>
      <div>
        <p className="text-sm font-medium text-slate-400 uppercase tracking-wider">{label}</p>
        <p className="text-3xl font-bold text-slate-800">{val}</p>
      </div>
    </div>
  );

  return (
    <div className="space-y-8 pb-12">
      {/* Engineering Wall Hero Section */}
      <div className="relative w-full h-64 md:h-80 rounded-[2.5rem] overflow-hidden shadow-2xl group border-4 border-white">
        <img 
          src="https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&q=80&w=2000" 
          alt="Modern Engineering Architecture" 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/80 via-slate-900/40 to-transparent"></div>
        <div className="absolute inset-0 p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex flex-col justify-center flex-1">
            <div className="flex items-center gap-2 mb-4">
               <span className="px-3 py-1 bg-indigo-600 text-[10px] font-bold text-white uppercase tracking-widest rounded-full">Precision Engineering</span>
               <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-pulse"></span>
            </div>
            <h1 className="text-3xl md:text-5xl font-black text-white leading-tight mb-4">
              Innovating Tomorrow <br/>with Precision & Logic
            </h1>
            <p className="text-slate-200 max-w-lg text-sm md:text-base mb-6 font-medium">
              Welcome to the PESDA Dashboard. Access world-class technical curriculum and join a community of professional engineering experts.
            </p>
            <div className="flex gap-4">
               <button className="px-6 py-2 bg-indigo-600 text-white rounded-xl font-bold text-sm shadow-lg hover:bg-indigo-700 transition-all">
                  Access Portal
               </button>
               <button className="px-6 py-2 bg-white/10 backdrop-blur-md text-white border border-white/20 rounded-xl font-bold text-sm hover:bg-white/20 transition-all">
                  Syllabus Overview
               </button>
            </div>
          </div>
          
          {/* Engineering Pic Logo / Emblem */}
          <div className="hidden lg:block">
            <EngineeringEmblem className="w-48 h-48" />
          </div>
        </div>
      </div>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Platform Insights</h1>
          <p className="text-slate-500">Global performance metrics for the academy.</p>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 bg-white border border-slate-200 rounded-lg text-slate-600 font-medium hover:bg-slate-50 transition-colors">
            <i className="fa-solid fa-download mr-2"></i> Report
          </button>
          <button className="px-4 py-2 bg-slate-900 text-white rounded-lg font-medium hover:bg-slate-800 transition-shadow shadow-md">
            <i className="fa-solid fa-plus mr-2"></i> Add Record
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <StatCard icon="fa-users-gear" label="Experts" val={memberCount} color="bg-indigo-600" />
        <StatCard icon="fa-user-graduate" label="Scholars" val={studentCount} color="bg-slate-700" />
        <StatCard icon="fa-book-open" label="Specializations" val={courseCount} color="bg-violet-600" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-bold text-slate-800">Enrollment Growth</h3>
            <select className="bg-slate-50 border border-slate-200 text-sm rounded-lg px-2 py-1 outline-none">
              <option>Yearly View</option>
              <option>Monthly View</option>
            </select>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                />
                <Bar dataKey="enrollment" fill="#4f46e5" radius={[6, 6, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-800 mb-6">Recent Enrollments</h3>
          <div className="space-y-4">
            {recentStudents.map((student) => (
              <div key={student.id} className="flex items-center gap-4 p-3 rounded-2xl hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-100">
                <div className="w-10 h-10 rounded-full bg-slate-200 overflow-hidden">
                  <img src={`https://i.pravatar.cc/100?u=${student.id}`} alt={student.name} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-slate-800 truncate">{student.name}</p>
                  <p className="text-xs text-slate-400 truncate">{student.enrolledCourse}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-bold text-indigo-600">{student.progress}%</p>
                  <div className="w-16 h-1 bg-slate-100 rounded-full mt-1">
                    <div className="bg-indigo-500 h-full rounded-full" style={{ width: `${student.progress}%` }}></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-6 py-3 text-sm font-bold text-slate-400 hover:text-indigo-600 border-t border-slate-50 transition-colors uppercase tracking-widest">
            View All Scholars
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
