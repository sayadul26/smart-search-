
import React from 'react';

const AdBanner: React.FC = () => {
  const campaigns = [
    {
      title: "Unlock 50% Off New Subscriptions",
      desc: "Limited time offer for institutional partners. Upgrade your workspace today.",
      color: "bg-indigo-600",
      image: "https://picsum.photos/seed/promo1/600/400"
    },
    {
      title: "Featured Course: Generative AI 101",
      desc: "Join 5,000+ students learning the fundamentals of Large Language Models.",
      color: "bg-emerald-600",
      image: "https://picsum.photos/seed/promo2/600/400"
    }
  ];

  return (
    <div className="space-y-12 pb-12">
      <div className="text-center max-w-2xl mx-auto">
        <h1 className="text-4xl font-extrabold text-slate-900 mb-4">Marketing Hub</h1>
        <p className="text-lg text-slate-500">Manage internal promotions and discover new platform features.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {campaigns.map((camp, i) => (
          <div key={i} className="group relative overflow-hidden rounded-[2.5rem] shadow-xl aspect-video md:aspect-auto">
            <img src={camp.image} className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt="ad" />
            <div className={`absolute inset-0 ${camp.color} mix-blend-multiply opacity-60`}></div>
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent"></div>
            
            <div className="absolute bottom-0 left-0 p-8 md:p-12 text-white">
               <span className="px-4 py-1 bg-white/20 backdrop-blur-md rounded-full text-[10px] font-bold uppercase tracking-widest mb-4 inline-block">Promoted</span>
               <h2 className="text-3xl md:text-4xl font-extrabold leading-tight mb-4">{camp.title}</h2>
               <p className="text-indigo-100/90 text-lg mb-8 max-w-md">{camp.desc}</p>
               <button className="px-8 py-3 bg-white text-slate-900 font-bold rounded-2xl hover:bg-slate-100 transition-colors shadow-lg">
                  Learn More
               </button>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-indigo-50 p-12 rounded-[3rem] border border-indigo-100 flex flex-col md:flex-row items-center gap-12">
        <div className="flex-1">
          <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-indigo-600 text-3xl shadow-lg mb-6">
            <i className="fa-solid fa-envelope-open-text"></i>
          </div>
          <h3 className="text-3xl font-extrabold text-slate-900 mb-4">Grow your teaching reach</h3>
          <p className="text-xl text-slate-600 mb-8">Launch your own course campaigns and reach millions of potential students through our integrated newsletter network.</p>
          <div className="flex flex-wrap gap-4">
            <button className="px-8 py-4 bg-indigo-600 text-white font-bold rounded-2xl shadow-xl hover:bg-indigo-700 transition-all">
              Launch Campaign
            </button>
            <button className="px-8 py-4 bg-white border border-slate-200 text-slate-600 font-bold rounded-2xl hover:bg-slate-50 transition-all">
              View Analytics
            </button>
          </div>
        </div>
        <div className="w-full md:w-1/3 aspect-square bg-white rounded-[2rem] shadow-2xl p-4 rotate-3 transform transition-transform hover:rotate-0">
          <img src="https://picsum.photos/seed/analytics/400/400" className="w-full h-full object-cover rounded-[1.5rem]" alt="preview" />
        </div>
      </div>
    </div>
  );
};

export default AdBanner;
